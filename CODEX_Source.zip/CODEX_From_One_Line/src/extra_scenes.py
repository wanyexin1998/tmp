"""Two procedural interludes for the 90 second film.

The host owns framebuffer state, background, typography and final compositing.
These functions only submit geometry through the existing Film drawing API.
"""
from functools import lru_cache
import math

import numpy as np


TAU = math.tau
CYAN = np.array([0.17, 0.83, 1.04])
ICE = np.array([0.74, 1.58, 1.73])
AMBER = np.array([1.35, 0.43, 0.12])


@lru_cache(maxsize=1)
def _lattice():
    coordinates = np.array([(x, y, z) for x in range(5)
                            for y in range(5) for z in range(5)], dtype=float)
    lookup = {tuple(p.astype(int)): i for i, p in enumerate(coordinates)}
    edges = []
    for point, i in lookup.items():
        for axis in range(3):
            neighbor = list(point)
            neighbor[axis] += 1
            if tuple(neighbor) in lookup:
                edges.append((i, lookup[tuple(neighbor)]))
    route = [(0, 0, 0), (1, 0, 0), (1, 1, 0), (2, 1, 0),
             (2, 1, 1), (3, 1, 1), (3, 2, 1), (3, 2, 2),
             (2, 2, 2), (2, 3, 2), (2, 3, 3), (3, 3, 3),
             (4, 3, 3), (4, 4, 3), (4, 4, 4)]
    return ((coordinates - 2) * 0.55, np.array(edges, dtype=np.int32),
            np.array([lookup[p] for p in route], dtype=np.int32))


@lru_cache(maxsize=1)
def _cube_template():
    vertices = np.array([[-1, -1, -1], [1, -1, -1], [1, 1, -1],
                         [-1, 1, -1], [-1, -1, 1], [1, -1, 1],
                         [1, 1, 1], [-1, 1, 1]], dtype=float)
    faces = [([0, 3, 2, 1], [0, 0, -1]), ([4, 5, 6, 7], [0, 0, 1]),
             ([0, 4, 7, 3], [-1, 0, 0]), ([1, 2, 6, 5], [1, 0, 0]),
             ([3, 7, 6, 2], [0, 1, 0]), ([0, 1, 5, 4], [0, -1, 0])]
    points = np.concatenate([vertices[face] for face, _ in faces])
    normals = np.concatenate([np.tile(normal, (4, 1)) for _, normal in faces])
    indices = np.concatenate([np.array([0, 1, 2, 0, 2, 3]) + 4 * i
                              for i in range(6)])
    return points, normals, indices


def _beacons(centers, colors, half_size=0.035):
    points, normals, indices = _cube_template()
    n = len(centers)
    size = np.broadcast_to(half_size, (n,))
    positions = centers[:, None, :] + points[None, :, :] * size[:, None, None]
    normals = np.broadcast_to(normals, positions.shape)
    colors = np.broadcast_to(np.asarray(colors), (n, 3))
    colors = np.broadcast_to(colors[:, None, :], positions.shape)
    data = np.concatenate([positions, normals, colors], axis=-1)
    indices = indices[None, :] + np.arange(n)[:, None] * 24
    return data.reshape(-1, 9).astype('f4'), indices.reshape(-1).astype('i4')


def _route_points(route, progress):
    progress = np.clip(np.asarray(progress), 0, len(route) - 1)
    segment = np.minimum(progress.astype(int), len(route) - 2)
    fraction = progress - segment
    return (route[segment] * (1 - fraction[..., None]) +
            route[segment + 1] * fraction[..., None])


def debug_scene(film, t):
    """42–54 s: inspect a Cartesian lattice, follow a fault and verify repair."""
    from render import smooth

    u = float(t) - 42.0
    base, edges, route_indices = _lattice()
    unfold = smooth(0.0, 1.8, u)
    p = base.copy()
    # Five logical layers slot into place before the inspection begins.
    p[:, 1] *= 1.0 + 0.24 * (1 - unfold)
    p[:, 0] += (1 - unfold) * 0.12 * np.sin(base[:, 1] * 5)
    p *= 1.0 + 0.009 * math.sin(u * 1.3)
    mvp, rot = film.transform(cx=1.58, cy=0.02, distance=7.65,
                              rx=0.24 + 0.035 * math.sin(u * 0.35),
                              ry=-0.50 + 0.052 * u, rz=-0.045)

    route = p[route_indices]
    repair = smooth(6.3, 9.9, u)
    palette = np.tile([0.13, 0.29, 0.34], (len(p), 1))
    palette[route_indices] = [0.19, 0.42, 0.45]
    anomaly = route_indices[8]
    palette[anomaly] = np.array([0.83, 0.22, 0.065]) * (1 - repair) + CYAN * repair
    sizes = np.full(len(p), 0.024)
    sizes[route_indices] = 0.033
    sizes[anomaly] = 0.075 - 0.024 * repair
    film.draw_mesh(_beacons(p, palette, sizes), mvp, rot, t, 0.85)
    film.draw_lights(p[edges].reshape(-1, 3), [0.11, 0.36, 0.44],
                     mvp, rot, 0.32, lines=True)

    # A scan plane makes the depth of the regular lattice immediately legible.
    scan_y = -1.25 + 2.5 * ((u * 0.13) % 1)
    proximity = np.exp(-((p[:, 1] - scan_y) / 0.19) ** 2)
    film.draw_lights(p, CYAN[None, :] * (0.12 + 0.65 * proximity[:, None]),
                     mvp, rot, 0.7, sizes=2.1 + 2.4 * proximity)

    progress = float(np.interp(u, [0, 1.2, 5.6, 6.7, 10.5, 12],
                               [0, 0, 8, 8, 14, 14]))
    segments = np.arange(len(route) - 1)
    fill = np.clip(progress - segments, 0, 1)
    end = route[:-1] + (route[1:] - route[:-1]) * fill[:, None]
    inspected = np.stack([route[:-1], end], axis=1).reshape(-1, 3)
    # Repair propagates from the fault in both directions, visibly changing state.
    distance = np.abs(segments + 0.5 - 8)
    fixed = smooth(0, 1.25, repair * 10.5 - distance)
    path_colors = AMBER[None, :] * (1 - fixed[:, None]) + ICE[None, :] * fixed[:, None]
    path_colors *= fill[:, None] * (0.75 + 0.2 * np.sin(u * 2 + segments[:, None] * 0.45))
    film.draw_lights(inspected, np.repeat(path_colors, 2, axis=0),
                     mvp, rot, 1.4, lines=True)

    # A tapered train of packets follows the right-angle route without jumping.
    lag = np.linspace(0, 0.7, 24)
    packets = _route_points(route, np.maximum(0, progress - lag))
    packet_color = AMBER * (1 - repair) + ICE * repair
    film.draw_lights(packets, packet_color[None, :] * np.exp(-lag[:, None] * 3),
                     mvp, rot, 1.0, sizes=2.5 + 4.5 * np.exp(-lag * 4))

    # Corner brackets surround the fault, then contract into the verified node.
    bracket_strength = smooth(1.3, 3.5, u) * (1 - smooth(9.0, 11.4, u))
    r = (0.16 + 0.025 * math.sin(u * 5)) * (1 - 0.45 * repair)
    bracket_lines = []
    for sx in (-1, 1):
        for sy in (-1, 1):
            for sz in (-1, 1):
                corner = np.array([sx, sy, sz], dtype=float) * r
                for axis in range(3):
                    end = corner.copy()
                    end[axis] *= 0.53
                    bracket_lines.extend([p[anomaly] + corner, p[anomaly] + end])
    film.draw_lights(np.asarray(bracket_lines), AMBER * (1 - repair) + ICE * repair,
                     mvp, rot, bracket_strength, lines=True)
    film.draw_lights(p[anomaly:anomaly + 1], AMBER * (1 - repair) + ICE * repair,
                     mvp, rot, 0.8 + 0.28 * (1 - repair) * math.sin(u * 6),
                     sizes=10 - 3 * repair)


@lru_cache(maxsize=8)
def _open_tube_indices(count, sides):
    a = np.arange(count - 1)[:, None] * sides + np.arange(sides)[None, :]
    b = np.arange(count - 1)[:, None] * sides + (np.arange(sides)[None, :] + 1) % sides
    c = a + sides
    d = b + sides
    return np.stack([a, b, c, b, d, c], axis=-1).reshape(-1).astype('i4')


def _open_tube(path, radius, colors, sides=16):
    """Stable tube for open helices, with no unwanted end-to-end closing seam."""
    tangent = np.gradient(path, axis=0)
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1)[:, None], 1e-9)
    guide = np.tile([0.0, 1.0, 0.0], (len(path), 1))
    # The fallback also keeps this helper valid for nearly straight end sections.
    guide[np.abs(tangent[:, 1]) > 0.94] = [1.0, 0.0, 0.0]
    normal = np.cross(tangent, guide)
    normal /= np.maximum(np.linalg.norm(normal, axis=1)[:, None], 1e-9)
    binormal = np.cross(tangent, normal)
    angle = np.arange(sides) * TAU / sides
    normals = (normal[:, None, :] * np.cos(angle)[None, :, None] +
               binormal[:, None, :] * np.sin(angle)[None, :, None])
    points = path[:, None, :] + radius * normals
    colors = np.broadcast_to(np.asarray(colors), (len(path), 3))
    colors = np.broadcast_to(colors[:, None, :], points.shape)
    vertices = np.concatenate([points, normals, colors], axis=-1)
    return vertices.reshape(-1, 9).astype('f4'), _open_tube_indices(len(path), sides)


def _helix(v, u, strand):
    from render import smooth

    breathe = 0.58 + 0.065 * math.sin(u * 0.9)
    radius = breathe * (0.84 + 0.16 * smooth(0, 1.7, u))
    angle = v * TAU * 1.3 + u * 0.42 + strand * math.pi
    x = radius * np.cos(angle) + 0.17 * np.sin(v * math.pi + u * 0.23)
    y = v * (1.56 + 0.16 * smooth(0, 2, u))
    z = radius * np.sin(angle)
    return np.stack([x, y, z], axis=-1)


def collaboration_scene(film, t):
    """66–76 s: two material strands exchange moving light through a double helix."""
    from render import smooth

    u = float(t) - 66.0
    mvp, rot = film.transform(cx=1.62, cy=0.0, distance=7.2,
                              rx=0.12 + 0.075 * math.sin(u * 0.38),
                              ry=-0.38 + u * 0.072, rz=-0.16 + 0.02 * math.sin(u * 0.4))
    v = np.linspace(-1, 1, 400)
    material = (np.array([0.13, 0.49, 0.58]), np.array([0.66, 0.25, 0.095]))
    emissive = (CYAN, AMBER)
    for strand in range(2):
        path = _helix(v, u, strand)
        shimmer = 0.8 + 0.2 * np.sin(v * 5 - u * 1.6 + strand)
        colors = material[strand][None, :] * shimmer[:, None]
        film.draw_mesh(_open_tube(path, 0.047, colors), mvp, rot, t, 1.0, 2)

        # Sparse points travel in opposite directions; every frame changes phase.
        seed = np.arange(110)
        direction = 1 if strand == 0 else -1
        pv = ((seed / 110 + u * 0.075 * direction) % 1) * 2 - 1
        particles = _helix(pv, u, strand)
        phase = seed * 2.399963 + u * 0.7
        particles[:, 0] += 0.075 * np.cos(phase)
        particles[:, 2] += 0.075 * np.sin(phase)
        light = 0.16 + 0.4 * (0.5 + 0.5 * np.sin(seed * 0.8 + u * 2)) ** 3
        film.draw_lights(particles, emissive[strand][None, :] * light[:, None],
                         mvp, rot, 0.65, sizes=1.4 + light * 2.2)

        # Two bright packets approach, meet, and then carry the pulse onward.
        center = -1 + 2 * ((u * 0.145 + strand * 0.5) % 1)
        if strand:
            center = -center
        tail = np.linspace(0, 0.2, 38)
        packet_v = center - tail * direction
        packet_v = (packet_v + 1) % 2 - 1
        packets = _helix(packet_v, u, strand)
        strength = np.exp(-tail * 15)
        film.draw_lights(packets, emissive[strand][None, :] * strength[:, None],
                         mvp, rot, 1.55, sizes=2 + 5 * strength)
        endpoints = _helix(np.array([-1., 1.]), u, strand)
        film.draw_lights(endpoints, emissive[strand], mvp, rot, 0.75, sizes=5)

    # Short, alternating connections suggest information exchange, without a cage.
    rung_v = np.linspace(-0.88, 0.88, 15)
    left, right = _helix(rung_v, u, 0), _helix(rung_v, u, 1)
    breathing = 0.5 + 0.5 * np.sin(rung_v * 5 + u * 1.5)
    rung_colors = np.array([0.15, 0.32, 0.37])[None, :] * (0.15 + 0.55 * breathing[:, None])
    film.draw_lights(np.stack([left, right], axis=1).reshape(-1, 3),
                     np.repeat(rung_colors, 2, axis=0), mvp, rot, 0.4, lines=True)

    # An exchange pulse sweeps between the strands, then settles for the edit.
    cycle = (u * 0.38) % 1
    exchange_v = np.array([0.52 * math.sin(u * 0.56)])
    a = _helix(exchange_v, u, 0)[0]
    b = _helix(exchange_v, u, 1)[0]
    fractions = np.clip(cycle - np.linspace(0, 0.15, 24), 0, 1)
    positions = a[None, :] * (1 - fractions[:, None]) + b[None, :] * fractions[:, None]
    exchange_color = CYAN * (1 - cycle) + AMBER * cycle
    envelope = smooth(0.3, 1.5, u) * (1 - 0.4 * smooth(8.5, 10, u))
    film.draw_lights(positions, exchange_color, mvp, rot, envelope * 0.55,
                     sizes=np.linspace(4.3, 1.3, 24))
