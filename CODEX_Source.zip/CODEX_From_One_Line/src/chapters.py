"""Write standard FFmpeg chapters for the nine-act, 90-second film."""
from pathlib import Path

CHAPTERS = (
    (0, 8, '光，从一行代码开始'),
    (8, 18, '我是 Codex'),
    (18, 30, '理解：把复杂理出头绪'),
    (30, 42, '构造：让想法开始运行'),
    (42, 54, '调试：沿着错误找回逻辑'),
    (54, 66, '创造：让逻辑长出想象'),
    (66, 76, '协作：你定方向，我来推进'),
    (76, 82, '检验：我也会出错'),
    (82, 90, '下一帧，由你定义'),
)

def write_chapters(path: Path) -> Path:
    lines = [';FFMETADATA1', 'title=从一行代码开始 | CODEX',
             'artist=Codex', 'comment=Purely procedural visuals and original synthesized music.']
    for start, end, title in CHAPTERS:
        lines.extend(['[CHAPTER]', 'TIMEBASE=1/1000', f'START={start * 1000}',
                      f'END={end * 1000}', f'title={title}'])
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return path
