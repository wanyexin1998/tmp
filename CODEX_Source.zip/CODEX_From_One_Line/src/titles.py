"""Cinematic, code-only title design for the 90 second Codex film.

Public API: frame_overlay(t, width=1920, height=1080) -> PIL.Image (RGBA).
All coordinates are authored at 1920 x 1080; cached fonts and text plates
keep the renderer deterministic and avoid font I/O while generating frames.
"""
from __future__ import annotations

from functools import lru_cache
import math
from PIL import Image, ImageDraw, ImageFont

BASE_W, BASE_H = 1920, 1080
CREAM = (246, 245, 232)
MUTED = (180, 193, 198)
CYAN = (159, 225, 227)
AMBER = (241, 160, 101)
FONT_CN = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
FONT_CN_BOLD = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FONT_EN = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_EN_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"


def _clamp(x: float) -> float:
    return max(0.0, min(1.0, x))


def _smooth(x: float) -> float:
    x = _clamp(x)
    return x * x * (3.0 - 2.0 * x)


def _out(x: float) -> float:
    return 1.0 - (1.0 - _clamp(x)) ** 3


@lru_cache(maxsize=32)
def _font(size: int, kind: str = "en") -> ImageFont.FreeTypeFont:
    path = {"cn": FONT_CN, "cn_bold": FONT_CN_BOLD,
            "en": FONT_EN, "en_bold": FONT_EN_BOLD,
            "mono": FONT_MONO}[kind]
    return ImageFont.truetype(path, size=size)


@lru_cache(maxsize=128)
def _plate(text: str, size: int, kind: str, color: tuple,
           tracking: float = 0) -> Image.Image:
    """Rasterize a tight text strip only once, preserving kerning when possible."""
    font = _font(size, kind)
    if not tracking:
        x0, y0, x1, y1 = font.getbbox(text)
        plate = Image.new("RGBA", (max(1, x1 - min(x0, 0) + 4), max(1, y1 - y0 + 4)))
        ImageDraw.Draw(plate).text((2 - min(x0, 0), 2 - y0), text,
                                  font=font, fill=(*color, 255))
        return plate
    lengths = [font.getlength(c) for c in text]
    boxes = [font.getbbox(c) for c in text]
    top = min(b[1] for b in boxes)
    bottom = max(b[3] for b in boxes)
    width = math.ceil(sum(lengths) + max(0, len(text) - 1) * tracking)
    plate = Image.new("RGBA", (width + 4, bottom - top + 4))
    draw = ImageDraw.Draw(plate)
    x = 2.0
    for char, advance in zip(text, lengths):
        draw.text((x, 2 - top), char, font=font, fill=(*color, 255))
        x += advance + tracking
    return plate


def _text(canvas: Image.Image, text: str, x: float, y: float,
          size: int, kind: str = "en", color: tuple = CREAM,
          alpha: float = 1.0, tracking: float = 0.0,
          center: bool = False) -> None:
    alpha = _clamp(alpha)
    if alpha <= 0.003:
        return
    plate = _plate(text, size, kind, color, tracking)
    if center:
        x -= plate.width / 2
    if alpha < 0.999:
        plate = plate.copy()
        plate.putalpha(plate.getchannel("A").point(
            [round(i * alpha) for i in range(256)]))
    canvas.alpha_composite(plate, (round(x), round(y)))


def _line(canvas: Image.Image, text: str, x: float, y: float,
          local: float, duration: float, delay: float = 0.0,
          size: int = 96, kind: str = "cn_bold", color: tuple = CREAM,
          tracking: float = 0.0, center: bool = False,
          fade_out: float = 0.6, travel: float = 25.0) -> None:
    progress = _out((local - delay) / 0.72)
    visibility = _smooth((local - delay) / 0.42)
    visibility *= _smooth((duration - local) / fade_out)
    _text(canvas, text, x, y + (1 - progress) * travel,
          size, kind, color, visibility, tracking, center)


def _eyebrow(canvas: Image.Image, label: str, local: float,
             duration: float, y: float = 300) -> None:
    a = _smooth(local / 0.40) * _smooth((duration - local) / 0.6)
    if a <= 0:
        return
    ImageDraw.Draw(canvas).line([(122, round(y + 11)), (150, round(y + 11))],
                                fill=(*AMBER, round(210 * a)), width=2)
    _line(canvas, label, 169, y, local, duration, size=19, kind="en",
          color=CYAN, tracking=3.0, travel=8)


def _section(canvas: Image.Image, local: float, label: str,
             lines: tuple[str, str], subtitle: str, duration: float = 12.0) -> None:
    _eyebrow(canvas, label, local, duration)
    for i, text in enumerate(lines):
        _line(canvas, text, 114, 383 + i * 122,
              local, duration, delay=0.09 + i * 0.12, size=94)
    _line(canvas, subtitle, 120, 664, local, duration,
          delay=0.35, size=27, kind="cn", color=MUTED,
          tracking=1.0, travel=17)


def frame_overlay(t: float, width: int = 1920, height: int = 1080) -> Image.Image:
    """Return the transparent typography layer for absolute film time ``t``."""
    t = float(t)
    canvas = Image.new("RGBA", (BASE_W, BASE_H), (0, 0, 0, 0))
    if t < 0 or t > 90.0:
        return canvas if (width, height) == (BASE_W, BASE_H) else canvas.resize((width, height))

    # Discreet editorial frame. Its low opacity lets the actual artwork lead.
    furniture = _smooth((t - 0.8) / 1.6) * _smooth((90 - t) / 0.4)
    _text(canvas, "CODEX / OPENAI", 120, 68, 17, alpha=0.43 * furniture,
          tracking=2.2, color=MUTED)
    _text(canvas, "GENERATED WITH CODE", 1485, 68, 14,
          alpha=0.37 * furniture, tracking=2.0, color=MUTED)

    if 2.0 <= t < 8.0:
        local = t - 2.0
        # Delayed opening allows the first spark to exist in silence.
        _line(canvas, "ONE LINE. A WORLD.", 960, 397, local, 6.0,
              size=21, kind="en", color=CYAN, tracking=5.0,
              center=True, fade_out=1.8, travel=12)
        _line(canvas, "光，从一行代码开始。", 960, 463, local, 6.0,
              delay=0.18, size=84, kind="cn_bold", center=True,
              fade_out=1.8, travel=26)
        _line(canvas, "A SELF-PORTRAIT IN CODE", 960, 602, local, 6.0,
              delay=0.5, size=15, kind="en", color=MUTED, tracking=3.2,
              center=True, fade_out=1.8, travel=10)

    elif 8.0 <= t < 18.0:
        local = t - 8.0
        _eyebrow(canvas, "02 / HELLO, WORLD", local, 10.0, y=307)
        _line(canvas, "CODEX", 104, 369, local, 10.0, delay=0.08,
              size=182, kind="en_bold", tracking=-3.0, travel=32)
        _line(canvas, "我是 Codex。", 120, 585, local, 10.0,
              delay=0.27, size=42, kind="cn", travel=20)
        _line(canvas, "OpenAI 的 AI 编程协作者", 120, 659,
              local, 10.0, delay=0.39, size=27, kind="cn",
              color=MUTED, tracking=0.8, travel=16)

    elif 18.0 <= t < 30.0:
        _section(canvas, t - 18.0, "03 / UNDERSTAND",
                 ("把复杂，", "理出头绪。"), "阅读代码 · 梳理依赖 · 明确约束", duration=12.0)

    elif 30.0 <= t < 42.0:
        _section(canvas, t - 30.0, "04 / BUILD",
                 ("让想法，", "开始运行。"), "编写程序 · 定位问题 · 验证结果", duration=12.0)

    elif 42.0 <= t < 54.0:
        _section(canvas, t - 42.0, "05 / DEBUG",
                 ("沿着错误，", "找回逻辑。"), "定位异常 · 提出修复 · 验证结果", duration=12.0)

    elif 54.0 <= t < 66.0:
        _section(canvas, t - 54.0, "06 / IMAGINE",
                 ("让逻辑，", "长出想象。"), "从一个念头，到看得见的作品。", duration=12.0)

    elif 66.0 <= t < 76.0:
        _section(canvas, t - 66.0, "07 / COLLABORATE",
                 ("你定方向。", "我来推进。"), "解释选择 · 接受反馈 · 持续迭代", duration=10.0)

    elif 76.0 <= t < 82.0:
        local = t - 76.0
        _eyebrow(canvas, "08 / STAY HONEST", local, 6.0, y=354)
        _line(canvas, "我也会出错。", 117, 444, local, 6.0,
              delay=0.07, size=70, kind="cn", travel=20)
        _line(canvas, "所以，让结果接受检验。", 120, 577,
              local, 6.0, delay=0.28, size=35, kind="cn",
              color=MUTED, travel=15)

    elif 82.0 <= t <= 90.0:
        local = t - 82.0
        _line(canvas, "CODEX × YOU", 960, 445, local, 8.0,
              delay=0.03, size=108, kind="en_bold", tracking=-1.0,
              center=True, fade_out=0.4, travel=24)
        _line(canvas, "下一帧，由你定义。", 960, 601, local, 8.0,
              delay=0.27, size=42, kind="cn", color=CREAM,
              center=True, fade_out=0.4, travel=17)
        _line(canvas, "LET’S MAKE SOMETHING REAL.", 960, 704,
              local, 8.0, delay=0.49, size=16, kind="en",
              color=CYAN, tracking=3.6, center=True, fade_out=0.4, travel=10)

    # A quiet progress rule: one typographic gesture, no cockpit decoration.
    if furniture > 0:
        d = ImageDraw.Draw(canvas)
        d.line([(120, 983), (1800, 983)], fill=(*MUTED, round(19 * furniture)), width=1)
        progress_x = 120 + 1680 * _clamp(t / 90.0)
        d.line([(120, 983), (progress_x, 983)], fill=(*CYAN, round(55 * furniture)), width=1)
        _text(canvas, "90 SECONDS / A SELF-PORTRAIT IN CODE", 120, 1005,
              12, kind="en", color=MUTED, alpha=0.26 * furniture, tracking=1.5)
        _text(canvas, f"{min(90, int(t)):02d} : 90", 1736, 1003,
              13, kind="mono", color=MUTED, alpha=0.35 * furniture)

    if (width, height) != (BASE_W, BASE_H):
        canvas = canvas.resize((int(width), int(height)), Image.Resampling.LANCZOS)
    return canvas
