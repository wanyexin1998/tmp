#!/usr/bin/env python3
"""A fully procedural 90 second film. Geometry, lighting, cameras and editing are code."""
from pathlib import Path
import os
os.environ.setdefault('LP_NUM_THREADS', '4')
import argparse, math, subprocess, time, json
import numpy as np
import moderngl
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
TAU=math.tau

def smooth(a,b,x):
    v=np.clip((x-a)/(b-a),0,1)
    return v*v*(3-2*v)

def rotation(ax,ay,az=0):
    cx,sx=np.cos(ax),np.sin(ax); cy,sy=np.cos(ay),np.sin(ay); cz,sz=np.cos(az),np.sin(az)
    rx=np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
    ry=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])
    rz=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
    return rz@ry@rx

def perspective(aspect):
    f=1/np.tan(np.radians(37)/2); n=.1; z=50
    return np.array([[f/aspect,0,0,0],[0,f,0,0],[0,0,(z+n)/(n-z),2*z*n/(n-z)],[0,0,-1,0]],dtype='f4')

QUAD_VERT='''#version 330
in vec2 in_pos; out vec2 uv;
void main(){uv=in_pos*.5+.5;gl_Position=vec4(in_pos,0,1);}
'''
BG_FRAG='''#version 330
in vec2 uv; out vec4 color; uniform vec2 resolution; uniform float time;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
void main(){
 vec2 p=(uv-.5)*vec2(resolution.x/resolution.y,1.);
 vec3 c=vec3(.0025,.004,.009);
 float loc=time<8.?.0:time<40.?.35:time<44.?.35:0.;
 vec2 d=p-vec2(loc,.03);
 c+=vec3(.005,.025,.034)*exp(-dot(d,d)*3.0);
 c+=vec3(.013,.006,.021)*exp(-length(p-vec2(-.6,-.2))*2.5);
 float reveal=smoothstep(1.8,7.,time);
 vec2 g=uv*vec2(130.,75.); vec2 id=floor(g); vec2 fp=fract(g)-.5;
 float h=hash(id);
 float star=exp(-dot(fp,fp)*500.)*step(.982,h);
 c+=vec3(.18,.28,.33)*star*(.3+.7*pow(sin(time*.22+h*60.),2.))*reveal;
 // Thin ruled horizon, visible chiefly during construction.
 float gridStrength=smoothstep(22.5,25.,time)*(1.-smoothstep(31.,32.,time));
 if(uv.y<.39){
   float z=.13/(.40-uv.y);float x=(uv.x-.62)*z*7.;
   float gx=abs(fract(x)-.5),gz=abs(fract(z*1.5+time*.10)-.5);
   float grid=(1.-smoothstep(.004,.018,min(gx,gz)))*exp(-z*.09);
   c+=vec3(.018,.070,.082)*grid*gridStrength;
 }
 c*=.12+.88*smoothstep(0.,3.,time);
 color=vec4(c,1.);
}
'''
MESH_VERT='''#version 330
in vec3 in_pos;in vec3 in_norm;in vec3 in_col; uniform mat4 mvp;uniform mat3 rot;
out vec3 norm;out vec3 pos;out vec3 tint;
void main(){vec3 p=rot*in_pos; norm=rot*in_norm;pos=p;tint=in_col;gl_Position=mvp*vec4(p,1.);}
'''
MESH_FRAG='''#version 330
in vec3 norm;in vec3 pos;in vec3 tint;out vec4 color;uniform float time;uniform float intensity;uniform float mode;
void main(){
 vec3 n=normalize(norm); if(!gl_FrontFacing)n=-n;
 vec3 v=normalize(vec3(0,0,8.)-pos); vec3 r=reflect(-v,n);
 float fres=pow(1.-max(dot(n,v),0.),3.);
 float key=pow(max(dot(n,normalize(vec3(-.5,1.,1.2))),0.),1.5);
 float rim=pow(max(dot(n,normalize(vec3(.8,.1,-.2))),0.),4.);
 // Analytic studio reflections: a white softbox, cool strip and warm edge.
 float strip=pow(max(0.,1.-abs(r.y-.50)*3.5),5.);
 float strip2=pow(max(0.,1.-abs(r.x+.5)*5.),8.);
 float spec=pow(max(dot(reflect(-normalize(vec3(-1.,1.,2.)),n),v),0.),55.);
 vec3 base=tint*(.075+.38*key)+vec3(.33,.64,.72)*rim*.5;
 vec3 c=base+vec3(.72,.91,1.)*strip*(.25+fres)*1.7;
 c+=vec3(.21,.76,.86)*strip2*.38;
 c+=vec3(1.,.52,.25)*pow(max(r.x,0.),10.)*.58;
 c+=vec3(1.4)*spec+fres*vec3(.06,.19,.23);
 if(mode>1.5) c+=tint*.08;
 color=vec4(c*intensity,1.);
}
'''
LIGHT_VERT='''#version 330
in vec3 in_pos; in vec3 in_col; in float in_size;
uniform mat4 mvp; uniform mat3 rot; uniform float scale;
out vec3 tint;
void main(){vec4 p=mvp*vec4(rot*in_pos,1);gl_Position=p;gl_PointSize=clamp(in_size*scale*7./p.w,1.,22.);tint=in_col;}
'''
POINT_FRAG='''#version 330
in vec3 tint;out vec4 color;uniform float intensity;
void main(){float r=length(gl_PointCoord-.5)*2.;if(r>1.)discard;
float a=exp(-r*r*5.)*(1.-smoothstep(.65,1.,r));color=vec4(tint*a*intensity,a);}
'''
LINE_FRAG='''#version 330
in vec3 tint;out vec4 color;uniform float intensity;
void main(){color=vec4(tint*intensity,1.);}
'''
BLUR_FRAG='''#version 330
in vec2 uv;out vec4 color;uniform sampler2D tex;uniform vec2 direction;uniform int first;
void main(){vec3 c=texture(tex,uv).rgb*.227027;
 c+=texture(tex,uv+direction*1.384615).rgb*.316216;
 c+=texture(tex,uv-direction*1.384615).rgb*.316216;
 c+=texture(tex,uv+direction*3.230769).rgb*.070270;
 c+=texture(tex,uv-direction*3.230769).rgb*.070270;
 if(first==1)c=max(c-.16,vec3(0));color=vec4(c,1.);}
'''
FINAL_FRAG='''#version 330
in vec2 uv;out vec4 color;uniform sampler2D tex;uniform sampler2D glow;uniform sampler2D titles;uniform float time;uniform vec2 resolution;
float hash(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){
 vec2 p=uv-.5;vec2 off=p*.0006;
 vec3 c=vec3(texture(tex,uv+off).r,texture(tex,uv).g,texture(tex,uv-off).b);
 c+=texture(glow,uv).rgb*.65;
 float flash=0.;
 flash+=.12*exp(-pow((time-8.08)*6.,2.));
 flash+=.08*exp(-pow((time-30.03)*8.,2.));
 flash+=.06*exp(-pow((time-54.03)*8.,2.));
 flash+=.15*exp(-pow((time-82.03)*6.,2.));
 c+=vec3(.55,.80,.88)*flash;
 c*=1.-.42*dot(p,p);
 c=pow(aces(c*1.35),vec3(1./2.2));
 c+=(hash(uv*resolution+fract(time)*331.)-.5)*.007;
 vec4 txt=texture(titles,vec2(uv.x,1.-uv.y));
 c=mix(c,txt.rgb,txt.a);
 float fade=smoothstep(0.,.6,time)*(1.-smoothstep(89.65,90.,time));
 color=vec4(c*fade,1.);
}
'''

def mesh_tube(path, radius=.14, sides=24, tint=(.2,.33,.38)):
    tangent=np.roll(path,-1,axis=0)-np.roll(path,1,axis=0)
    tangent/=np.linalg.norm(tangent,axis=1)[:,None]
    guide=np.tile([0,0,1.],(len(path),1))
    # A stable local Frenet frame for closed loops.
    n=np.cross(tangent,guide);n/=np.linalg.norm(n,axis=1)[:,None]
    b=np.cross(tangent,n)
    v=np.arange(sides)*TAU/sides
    normals=n[:,None,:]*np.cos(v)[None,:,None]+b[:,None,:]*np.sin(v)[None,:,None]
    pos=path[:,None,:]+normals*radius
    col=np.broadcast_to(tint,pos.shape)
    data=np.concatenate([pos,normals,col],axis=2).reshape(-1,9).astype('f4')
    a=np.arange(len(path))[:,None]*sides+np.arange(sides)[None,:]
    bb=np.arange(len(path))[:,None]*sides+(np.arange(sides)[None,:]+1)%sides
    cc=((np.arange(len(path))[:,None]+1)%len(path))*sides+np.arange(sides)[None,:]
    dd=((np.arange(len(path))[:,None]+1)%len(path))*sides+(np.arange(sides)[None,:]+1)%sides
    idx=np.stack([a,bb,cc,bb,dd,cc],axis=-1).reshape(-1).astype('i4')
    return data,idx

def knot_geometry():
    u=np.linspace(0,TAU,360,endpoint=False)
    p=np.stack([(1.28+.45*np.cos(3*u))*np.cos(2*u),(1.28+.45*np.cos(3*u))*np.sin(2*u),.58*np.sin(3*u)],1)
    return mesh_tube(p,.235,32,tint=(.31,.40,.43))

def flower_geometry(t):
    nu,nv=280,20
    u=np.linspace(0,TAU,nu,endpoint=False)[:,None];v=np.linspace(-1,1,nv)[None,:]
    def shape(u,v):
        phase=t*.22
        rad=1.25+.36*np.cos(5*u+phase)+v*.33*np.cos(2.5*u+phase)
        x=rad*np.cos(u);y=rad*np.sin(u)
        z=.50*np.sin(5*u+phase)+v*.54*np.sin(2.5*u+phase)
        return np.stack([x+v*0,y+v*0,z],-1)
    p=shape(u,v);pu=shape(u+.001,v)-p;pv=shape(u,v+.001)-p
    norm=np.cross(pu,pv);norm/=np.maximum(np.linalg.norm(norm,axis=-1)[...,None],1e-8)
    fac=(.5+.5*np.sin(u*2+v*1.5+t*.3))[...,None]
    color=np.array([.12,.64,.72])*(1-fac)+np.array([.84,.25,.13])*fac
    data=np.concatenate([p,norm,color],axis=-1).reshape(-1,9).astype('f4')
    a=np.arange(nu)[:,None]*nv+np.arange(nv-1)[None,:]
    b=a+1;c=((np.arange(nu)[:,None]+1)%nu)*nv+np.arange(nv-1)[None,:];d=c+1
    idx=np.stack([a,b,c,b,d,c],-1).reshape(-1).astype('i4')
    return data,idx

CUBE_POS=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],float)
CUBE_FACES=[([0,3,2,1],[0,0,-1]),([4,5,6,7],[0,0,1]),([0,4,7,3],[-1,0,0]),([1,2,6,5],[1,0,0]),([3,7,6,2],[0,1,0]),([0,1,5,4],[0,-1,0])]

def cubes_geometry(t):
    progress=smooth(24.,29.,t)
    arr=[];indices=[]
    for j in range(5):
      for i in range(5):
        h=1+int((math.sin(i*1.7+j*.7)+1)*1.8)
        for k in range(h):
          center=np.array([(i-2)*.54,(-1.5+k*.49),(j-2)*.54])
          arrive=smooth(24+(i+j+k)*.17,26.3+(i+j+k)*.17,t)
          offset=np.array([math.sin(i+j*3+k)*1.6,3.4+k*.4,math.cos(j+i*2)*1.5])*(1-arrive)
          center+=offset
          size=.212*(.5+.5*arrive)
          tint=[.15,.37,.42] if (i+j+k)%5 else [.8,.28,.075]
          for face,normal in CUBE_FACES:
            start=len(arr)
            for n in face:arr.append([*(center+CUBE_POS[n]*size),*normal,*tint])
            indices.extend([start,start+1,start+2,start,start+2,start+3])
    return np.array(arr,'f4'),np.array(indices,'i4')

class Film:
 def __init__(self,w=1920,h=1080):
    self.w,self.h=w,h
    self.ctx=moderngl.create_standalone_context(backend='egl')
    self.ctx.enable(moderngl.PROGRAM_POINT_SIZE)
    self.programs={}
    self.quads={}
    q=self.ctx.buffer(np.array([-1,-1,1,-1,-1,1,1,1],'f4').tobytes())
    for name,frag in [('bg',BG_FRAG),('blur',BLUR_FRAG),('final',FINAL_FRAG)]:
        p=self.ctx.program(vertex_shader=QUAD_VERT,fragment_shader=frag)
        self.programs[name]=p;self.quads[name]=self.ctx.simple_vertex_array(p,q,'in_pos')
    self.mesh_p=self.ctx.program(vertex_shader=MESH_VERT,fragment_shader=MESH_FRAG)
    self.point_p=self.ctx.program(vertex_shader=LIGHT_VERT,fragment_shader=POINT_FRAG)
    self.line_p=self.ctx.program(vertex_shader=LIGHT_VERT,fragment_shader=LINE_FRAG)
    self.scene_tex=self.ctx.texture((w,h),4,dtype='f2');self.scene_tex.filter=(moderngl.LINEAR,moderngl.LINEAR)
    self.scene=self.ctx.framebuffer([self.scene_tex],self.ctx.depth_renderbuffer((w,h)))
    self.small=[]
    for i in range(2):
        tx=self.ctx.texture((w//4,h//4),4,dtype='f2');tx.filter=(moderngl.LINEAR,moderngl.LINEAR)
        self.small.append((tx,self.ctx.framebuffer([tx])))
    self.out=self.ctx.simple_framebuffer((w,h),components=3)
    self.title=self.ctx.texture((w,h),4);self.title.filter=(moderngl.LINEAR,moderngl.LINEAR)
    self.proj=perspective(w/h)
    self.knot=knot_geometry()
    self.rng=np.random.default_rng(12)
    n=3400
    self.rand=self.rng.random((n,5))
    self.star=self.rng.uniform(-1,1,(900,3))*[7,4,5]
    self.star[:,2]-=1
    n=210;ind=np.arange(n);y=1-2*(ind+.5)/n;phi=ind*math.pi*(3-math.sqrt(5))
    self.nodes=np.stack([np.cos(phi)*np.sqrt(1-y*y),y,np.sin(phi)*np.sqrt(1-y*y)],1)*1.67
    dist=np.linalg.norm(self.nodes[:,None]-self.nodes[None,:],axis=-1)
    self.edges=np.array([(i,j) for i in range(n) for j in range(i+1,n) if dist[i,j]<.48])
    self.last_pct=-1

 def transform(self,cx=1.4,cy=0,distance=8.,rx=.2,ry=.3,rz=0):
    view=np.eye(4,dtype='f4');view[:3,3]=[cx,cy,-distance]
    return self.proj@view,rotation(rx,ry,rz).astype('f4')

 def uniforms(self,p,mvp,rot,intensity=1):
    p['mvp'].write(mvp.T.tobytes());p['rot'].write(rot.T.tobytes());p['intensity'].value=float(intensity)
    if 'scale' in p:p['scale'].value=self.h/1080

 def draw_mesh(self,geo,mvp,rot,t,intensity=1,mode=0):
    dat,idx=geo;p=self.mesh_p
    self.uniforms(p,mvp,rot,intensity);p['mode'].value=float(mode)
    vbo=self.ctx.buffer(dat.tobytes());ibo=self.ctx.buffer(idx.tobytes())
    vao=self.ctx.vertex_array(p,[(vbo,'3f 3f 3f','in_pos','in_norm','in_col')],ibo)
    self.ctx.enable(moderngl.DEPTH_TEST);self.ctx.disable(moderngl.BLEND)
    vao.render();vao.release();vbo.release();ibo.release()

 def draw_lights(self,pos,colors,mvp,rot,intensity=1,sizes=2.5,lines=False):
    if len(pos)==0 or intensity<.001:return
    p=self.line_p if lines else self.point_p
    col=np.broadcast_to(colors,(len(pos),3))
    sz=np.broadcast_to(sizes,(len(pos),))[:,None]
    data=np.concatenate([pos,col,sz],axis=1).astype('f4')
    self.uniforms(p,mvp,rot,intensity)
    vb=self.ctx.buffer(data.tobytes())
    if lines:vao=self.ctx.vertex_array(p,[(vb,'3f 3f 4x','in_pos','in_col')])
    else:vao=self.ctx.vertex_array(p,[(vb,'3f 3f 1f','in_pos','in_col','in_size')])
    self.ctx.enable(moderngl.BLEND);self.ctx.blend_func=(moderngl.ONE,moderngl.ONE)
    self.ctx.depth_mask=False
    vao.render(mode=moderngl.LINES if lines else moderngl.POINTS)
    self.ctx.depth_mask=True
    vao.release();vb.release()

 def orbit(self,t,mvp,rot,radius=2.3,intensity=.25,count=3):
    u=np.linspace(0,TAU,450)
    for j in range(count):
      r=radius+j*.09
      pp=np.stack([np.cos(u)*r,np.sin(u)*r,np.zeros_like(u)],1)
      pp=pp@rotation(.65+j*.6,.18+j*.5,t*.04).T
      line=np.stack([pp[:-1],pp[1:]],1).reshape(-1,3)
      self.draw_lights(line,[.16,.51,.59],mvp,rot,intensity,lines=True)
      k=int((t*.075+j*.25)%1*449)
      self.draw_lights(pp[k:k+1],[.7,1.4,1.5],mvp,rot,intensity*3,sizes=7)

 def render_scene(self,actual_time):
    # Each chapter retains its authored motion; two new scenes complete the 90s arc.
    t=actual_time
    extra=None
    if 8<=t<18:t=8+(t-8)*.8
    elif 18<=t<30:t=16+(t-18)*(2/3)
    elif 30<=t<42:t=24+(t-30)*(2/3)
    elif 42<=t<54:extra='debug'
    elif 54<=t<66:t=32+(t-54)*(2/3)
    elif 66<=t<76:extra='collaboration'
    elif 76<=t<82:t=40+(t-76)*(2/3)
    elif 82<=t<=90:t=44+(t-82)*.5
    ctx=self.ctx;self.scene.use();ctx.viewport=(0,0,self.w,self.h);ctx.clear(0,0,0,1,depth=1)
    ctx.disable(moderngl.DEPTH_TEST|moderngl.BLEND)
    self.programs['bg']['resolution'].value=(self.w,self.h);self.programs['bg']['time'].value=t
    self.quads['bg'].render(moderngl.TRIANGLE_STRIP)
    # Dim distant motes persist across every edit.
    mvp,rot=self.transform(cx=0,rx=0,ry=0)
    sp=self.star.copy();sp[:,0]+=.05*np.sin(t*.2+sp[:,2]);sp[:,1]+=.03*np.cos(t*.13+sp[:,0])
    self.draw_lights(sp,[.20,.36,.42],mvp,rot,.20*smooth(1.5,8,t),sizes=1.5)
    if extra:
      from extra_scenes import debug_scene, collaboration_scene
      (debug_scene if extra=='debug' else collaboration_scene)(self,actual_time)
      return
    if t<8:
      self.ignition(t)
    elif t<16:
      u=t-8;mvp,rot=self.transform(cx=1.25,cy=.03,distance=7.4-1.5*(1-smooth(0,1.7,u))-.15*np.sin(u*.4)-.6*smooth(6.8,8.,u),rx=.36+u*.065,ry=u*.19+.3*smooth(6.5,8.,u),rz=-.2)
      amp=.72+.28*smooth(8,9,t)
      self.draw_mesh(self.knot,mvp,rot,t,amp)
      self.orbit(t,mvp,rot,2.25,.2,2)
      self.knot_particles(t,mvp,rot,.25)
    elif t<24:
      u=t-16;mvp,rot=self.transform(cx=1.5,distance=7.6,rx=.14,ry=u*.16,rz=-.12)
      p=self.nodes*(1+.025*np.sin(t*2+self.nodes[:,1]*4))[:,None]
      p+=(1-smooth(16,17.6,t))*np.sin(self.nodes*12.+t)*.55
      edgepos=p[self.edges].reshape(-1,3)
      ealpha=.1+.8*smooth(16.3,20.,t)
      self.draw_lights(edgepos,[.09,.36,.43],mvp,rot,ealpha*.6,lines=True)
      cols=np.tile([.25,.8,1.0],(len(p),1));cols[::11]=[1.4,.48,.16]
      sizes=2.5+2*(.5+.5*np.sin(t*2+np.arange(len(p))*.6))
      self.draw_lights(p,cols,mvp,rot,1,sizes=sizes)
      # A traveling path traces connected vertices.
      k=int(u*19)%len(p);active=np.arange(k,min(k+8,len(p)))
      self.draw_lights(p[active],[1.,1.9,2.1],mvp,rot,1,sizes=7)
      self.orbit(t,mvp,rot,1.94,.25,3)
      # Interior concentric shell.
      self.draw_lights(p*.74,[.12,.26,.34],mvp,rot,.5,sizes=2)
    elif t<32:
      u=t-24;mvp,rot=self.transform(cx=1.6,cy=.05,distance=8.2,rx=.43,ry=-.55+u*.11,rz=.02)
      self.draw_mesh(cubes_geometry(t),mvp,rot,t,1.05,1)
      self.orbit(t,mvp,rot,2.65,.1,1)
      # Streams of assembly instructions converge from above.
      a=self.rand[:450];pp=np.stack([(a[:,0]-.5)*3.3,(a[:,1]*5-t*.7)%5-1.7,(a[:,2]-.5)*3.3],1)
      self.draw_lights(pp,[.2,.8,.9],mvp,rot,.42*(1-.7*smooth(27,31,t)),sizes=2.2)
    elif t<40:
      u=t-32;mvp,rot=self.transform(cx=1.35,distance=6.8-.3*np.sin(u*.3)-1.1*(1-smooth(0,1.5,u)),rx=.50+u*.04,ry=u*.18,rz=.15)
      self.draw_mesh(flower_geometry(t),mvp,rot,t,1.05,2)
      self.ribbon_filaments(t,mvp,rot)
      self.orbit(t,mvp,rot,2.08,.17,1)
    elif t<44:
      u=t-40;mvp,rot=self.transform(cx=1.5,distance=8.0,rx=.15+u*.06,ry=u*.12)
      self.orbit(t,mvp,rot,1.6,.35,3)
      p=self.nodes*.7
      self.draw_lights(p,[.22,.58,.65],mvp,rot,.45,sizes=2.5)
      # A single warm point, with a trace that remains visibly inspectable.
      self.draw_lights(np.array([[0,0,0]]),[2.,.65,.23],mvp,rot,1,sizes=13)
    else:self.finale(t)

 def knot_particles(self,t,mvp,rot,intensity):
    a=self.rand;u=a[:,0]*TAU
    r=1.28+.45*np.cos(3*u)
    p=np.stack([r*np.cos(2*u),r*np.sin(2*u),.58*np.sin(3*u)],1)
    p+=np.stack([np.cos(a[:,1]*TAU),np.sin(a[:,1]*TAU),np.sin(a[:,2]*TAU)],1)*(.25+a[:,3:4]*.20)
    self.draw_lights(p,[.22,.9,1.1],mvp,rot,intensity,sizes=1.5)

 def ignition(self,t):
    mvp,rot=self.transform(cx=0,distance=7.5,rx=.3,ry=t*.05)
    a=self.rand;u=a[:,0]*TAU
    growth=smooth(1.5,6.8,t)
    r=(.025+growth*(.8+1.5*a[:,1]))
    angle=u+t*(.05+a[:,2]*.25)
    p=np.stack([r*np.cos(angle),r*np.sin(angle)*.75,(a[:,2]-.5)*1.7*growth],1)
    cols=np.tile([.23,.75,.86],(len(p),1));cols[::7]=[1.4,.51,.18]
    intensity=smooth(1.2,3,t)*(1-.45*smooth(6,8,t))
    self.draw_lights(p,cols,mvp,rot,intensity*.58,sizes=1.2+2.4*a[:,3])
    # Expanding thin shock wave, followed by scattered radial traces.
    u=np.linspace(0,TAU,720)
    for j in range(3):
      rr=max(.015,(t-1.65-j*.2)*.52)
      pp=np.stack([rr*np.cos(u),rr*np.sin(u),np.zeros_like(u)],1)
      lines=np.stack([pp[:-1],pp[1:]],1).reshape(-1,3)
      self.draw_lights(lines,[.35,.95,1.3],mvp,rot,float(np.exp(-max(t-2,0)*.6))*.55*smooth(1.65,1.9,t),lines=True)
    # White cursor turns into the first photon.
    if t<2.4:
      amp=(.4+.6*(math.sin(t*6)>0))*(1-smooth(1.7,2.4,t))
      self.draw_lights(np.array([[0,-.075,0],[0,.075,0]]),[.8,1.4,1.6],mvp,rot,amp,lines=True)
    # Pre-reveal radial acceleration through the ring.
    speed=smooth(6.1,7.9,t)
    if speed>0:
      a=self.rand[:700];ang=a[:,0]*TAU;rad=.7+a[:,1]*3
      p1=np.stack([rad*np.cos(ang),rad*np.sin(ang),(a[:,2]-.5)*3],1)
      p2=p1*(1+.22*speed)
      self.draw_lights(np.stack([p1,p2],1).reshape(-1,3),[.10,.40,.55],mvp,rot,speed*.75,lines=True)

 def ribbon_filaments(self,t,mvp,rot):
    u=np.linspace(0,TAU,700)
    for j in range(12):
      phase=t*.22;v=(j/11-.5)*2
      rad=1.25+.36*np.cos(5*u+phase)+v*.39*np.cos(2.5*u+phase)
      p=np.stack([rad*np.cos(u),rad*np.sin(u),.5*np.sin(5*u+phase)+v*.64*np.sin(2.5*u+phase)],1)
      line=np.stack([p[:-1],p[1:]],1).reshape(-1,3)
      color=[.12,.75,.9] if j%2 else [.95,.34,.12]
      self.draw_lights(line,color,mvp,rot,.23,lines=True)

 def finale(self,t):
    u=t-44;mvp,rot=self.transform(cx=0,distance=7.5,rx=.06,ry=.05)
    a=self.rand;angle=a[:,0]*TAU+u*.075
    converge=smooth(44,46.7,t)
    rr=(1.95+(a[:,1]-.5)*.9)*(1-.15*converge)
    z=(a[:,2]-.5)*1.0
    p=np.stack([rr*np.cos(angle)*1.22,rr*np.sin(angle),z],1)
    col=np.tile([.17,.63,.72],(len(p),1));col[::3]=[1.2,.47,.14]
    self.draw_lights(p,col,mvp,rot,.65,sizes=1.4+2*a[:,3])
    v=np.linspace(0,TAU,1000)
    for j in range(7):
      r=1.7+j*.026
      pp=np.stack([r*1.22*np.cos(v),r*np.sin(v),np.zeros_like(v)],1)
      warm=smooth(44.,47.,t)
      ringcol=np.array([.18,.7,.85])*(1-warm)+np.array([1.05,.45,.18])*warm
      self.draw_lights(np.stack([pp[:-1],pp[1:]],1).reshape(-1,3),ringcol,mvp,rot,.20,lines=True)
    flare=np.exp(-u*2.8)
    rad=1.5+a[:800,1]*3.0
    pp=np.stack([rad*np.cos(angle[:800]),rad*np.sin(angle[:800]),z[:800]],1)
    self.draw_lights(np.stack([pp,pp*(1+flare*.3)],1).reshape(-1,3),[.25,.7,.9],mvp,rot,float(flare)*.55,lines=True)

 def frame(self,t):
    self.render_scene(t)
    ctx=self.ctx;ctx.disable(moderngl.DEPTH_TEST|moderngl.BLEND)
    blur=self.programs['blur'];blur['tex'].value=0
    self.scene_tex.use(0)
    self.small[0][1].use();ctx.viewport=(0,0,self.w//4,self.h//4)
    blur['direction'].value=(2/self.w,0);blur['first'].value=1
    self.quads['blur'].render(moderngl.TRIANGLE_STRIP)
    for i in range(4):
      src=i%2;dst=1-src
      self.small[src][0].use(0);self.small[dst][1].use()
      blur['first'].value=0;blur['direction'].value=(0,4/self.h) if i%2==0 else (4/self.w,0)
      self.quads['blur'].render(moderngl.TRIANGLE_STRIP)
    from titles import frame_overlay
    overlay=frame_overlay(t,self.w,self.h)
    self.title.write(overlay.tobytes())
    self.out.use();ctx.viewport=(0,0,self.w,self.h)
    self.scene_tex.use(0);self.small[0][0].use(1);self.title.use(2)
    p=self.programs['final'];p['tex'].value=0;p['glow'].value=1;p['titles'].value=2;p['time'].value=t;p['resolution'].value=(self.w,self.h)
    self.quads['final'].render(moderngl.TRIANGLE_STRIP)
    return self.out.read(components=3,alignment=1)

 def png(self,t,path):
    data=self.frame(t)
    Image.frombytes('RGB',(self.w,self.h),data).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(path)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--width',type=int,default=1920);ap.add_argument('--height',type=int,default=1080);ap.add_argument('--fps',type=int,default=30)
    ap.add_argument('--preview',action='store_true');ap.add_argument('--start',type=float,default=0);ap.add_argument('--end',type=float,default=90);ap.add_argument('--output',default=str(ROOT/'output'/'codex_from_one_line.mp4'))
    args=ap.parse_args();film=Film(args.width,args.height)
    print('Renderer:',film.ctx.info['GL_RENDERER'],flush=True)
    if args.preview:
      folder=ROOT/'output'/'frames';folder.mkdir(exist_ok=True)
      for t in [1,4,11,23,37,48,60,71,79,86]:
        film.png(t,folder/f'{t:04.1f}.png');print('preview',t,flush=True)
      return
    out=Path(args.output);out.parent.mkdir(exist_ok=True,parents=True)
    cmd=['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{args.width}x{args.height}','-r',str(args.fps),'-i','-','-vf','vflip','-an','-c:v','libx264','-preset','fast','-crf','17','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    n=int((args.end-args.start)*args.fps);start=time.monotonic()
    try:
      for i in range(n):
        t=args.start+i/args.fps
        proc.stdin.write(film.frame(t))
        if i%60==0:print(f'{i}/{n} frames; timeline={t:.1f}s; elapsed={time.monotonic()-start:.1f}s',flush=True)
    finally:
      proc.stdin.close()
    if proc.wait()!=0:raise RuntimeError('ffmpeg encoding failed')
    print(f'Done: {out}; {time.monotonic()-start:.1f}s',flush=True)

if __name__=='__main__':main()
