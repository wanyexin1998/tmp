#!/usr/bin/env python3
"""Generate the procedural soundtrack, render the film, then mux an MP4."""
from pathlib import Path
import argparse
import subprocess
import sys
from src.chapters import write_chapters

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "output"


def positive_int(value: str) -> int:
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("必须为正整数")
    return number


def main() -> None:
    parser = argparse.ArgumentParser(description="从一行代码开始：生成 90 秒纯代码影片")
    parser.add_argument("--preview", action="store_true", help="仅生成关键帧 PNG，不合成音频或视频")
    parser.add_argument("--width", type=positive_int, default=1920)
    parser.add_argument("--height", type=positive_int, default=1080)
    parser.add_argument("--fps", type=positive_int, default=30)
    args = parser.parse_args()
    if args.width < 4 or args.height < 4 or args.width % 2 or args.height % 2:
        parser.error("宽度与高度须为至少 4 的偶数；建议保持 16:9")

    OUTPUT.mkdir(parents=True, exist_ok=True)
    render_command = [
        sys.executable, str(ROOT / "src" / "render.py"),
        "--width", str(args.width), "--height", str(args.height),
        "--fps", str(args.fps),
    ]
    if args.preview:
        subprocess.run([*render_command, "--preview"], cwd=ROOT, check=True)
        print(f"关键帧：{OUTPUT / 'frames'}", flush=True)
        return

    subprocess.run([sys.executable, str(ROOT / "src" / "synth_score.py")],
                   cwd=ROOT, check=True)
    visuals = OUTPUT / "visuals.mp4"
    subprocess.run([*render_command, "--output", str(visuals)], cwd=ROOT, check=True)
    final = OUTPUT / "CODEX_From_One_Line.mp4"
    chapters = write_chapters(OUTPUT / "chapters.ffmeta")
    subprocess.run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "warning",
        "-i", str(visuals), "-i", str(OUTPUT / "score.wav"),
        "-f", "ffmetadata", "-i", str(chapters),
        "-map", "0:v:0", "-map", "1:a:0", "-map_metadata", "2", "-map_chapters", "2",
        "-c:v", "copy", "-c:a", "aac", "-b:a", "320k",
        "-movflags", "+faststart", "-shortest", str(final),
    ], cwd=ROOT, check=True)
    subprocess.run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", "11",
        "-i", str(final), "-frames:v", "1", "-q:v", "2", "-update", "1",
        str(OUTPUT / "poster.jpg"),
    ], cwd=ROOT, check=True)
    print(f"成片：{final}", flush=True)


if __name__ == "__main__":
    main()
