# 从一行代码开始 · CODEX

一部 90 秒、九幕结构的中文动态叙事短片，介绍 Codex：理解代码、构造程序、定位问题、发挥想象，与用户协作，并让结果接受检验。无配音；以动态文字、程序化三维画面和原创电子配乐完成叙事。

画面与音乐全部由代码生成，不使用外部图片、视频、音频或采样素材。文字使用系统字体。所有随机源使用固定种子。

## 环境

- Python 3.10 或更新版本。
- Linux，支持 EGL 的 OpenGL 3.3 环境；可以使用 Mesa 软件渲染，无须桌面显示器。
- FFmpeg，包含 `libx264` 与 AAC 编码器，并可通过 `PATH` 调用。
- 系统字体 Noto Sans CJK 与 DejaVu Sans。

Debian / Ubuntu 安装示例：

```bash
sudo apt-get update
sudo apt-get install -y python3-venv ffmpeg libegl1 libgl1-mesa-dri fonts-noto-cjk fonts-dejavu-core
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

字体路径写在 `src/titles.py` 中：`/usr/share/fonts/opentype/noto/` 下的 NotoSansCJK Regular / Bold，以及 `/usr/share/fonts/truetype/dejavu/` 下的 DejaVu Sans / Sans Bold / Sans Mono。使用其他发行版时，可修改这些路径以匹配实际安装位置。

## 生成影片

在项目目录运行：

```bash
python build.py
```

脚本依次生成配乐、渲染画面、合成音视频，输出 `output/CODEX_From_One_Line.mp4`。原始配乐保存在 `output/score.wav`，无声画面保存在 `output/visuals.mp4`。重复运行会覆盖同名生成文件。

先检查关键帧：

```bash
python build.py --preview --width 960 --height 540
```

关键帧保存在 `output/frames/`；此模式仅渲染 PNG。降低分辨率与帧率生成完整预览影片：

```bash
python build.py --width 960 --height 540 --fps 15
```

宽度和高度须为偶数，建议保持 16:9。可用 `LIBGL_ALWAYS_SOFTWARE=1 python build.py` 强制 Mesa 软件渲染；完整渲染所需时间取决于 CPU / GPU 性能。

生成后可双击 `watch.html`，在本地剧场中观看并按九幕跳转。页面完全离线，无自动播放。

## 代码结构

| 文件 | 作用 |
| --- | --- |
| `build.py` | 一键调用配乐、渲染和 FFmpeg 合成；各步骤失败即停止。 |
| `src/render.py` | NumPy 生成三维几何，ModernGL / GLSL 完成光照、粒子、镜头、辉光和最终合成。 |
| `src/extra_scenes.py` | 立体晶格调试路径、双螺旋协作轨道与跨轨脉冲。 |
| `src/titles.py` | Pillow 渲染中英文动态排版；字体与文字图层缓存，按时间实现错落上浮和渐隐。 |
| `src/synth_score.py` | NumPy / SciPy 合成振荡器、FM 音色、噪声打击乐、延迟与混响，输出立体声 WAV。 |
| `src/chapters.py` | 为 MP4 生成九个中文章节标记，支持播放器按幕跳转。 |
| `soundtrack_notes.md` | 配乐段落、合成方式与生成时测得的音量信息。 |

三维画面包括参数化三叶扭结与圆管网格、Fibonacci 球面上的邻近节点连线、错时聚合的立方体阵列、随时间变化的参数化花瓣曲面，以及环形粒子。调试章节使用节点与连线追踪异常和修复过程；协作章节以双轨几何与运动表现用户和 Codex 的共同推进。材质使用解析光照和模拟摄影棚反射；后期包含辉光、色调映射、暗角与轻微颗粒，均由着色器计算。

音乐为 120 BPM，与九幕章节的转场对齐；76 秒处留白，82 秒进入终章。没有语音合成或外部音乐服务。

## 九幕时间线

| 时间 | 章节 |
| --- | --- |
| 00–08 秒 | 光，从一行代码开始。 |
| 08–18 秒 | 我是 Codex。 |
| 18–30 秒 | 把复杂，理出头绪。 |
| 30–42 秒 | 让想法，开始运行。 |
| 42–54 秒 | 沿着错误，找回逻辑。 |
| 54–66 秒 | 让逻辑，长出想象。 |
| 66–76 秒 | 你定方向。我来推进。 |
| 76–82 秒 | 我也会出错。所以，让结果接受检验。 |
| 82–90 秒 | CODEX × YOU：下一帧，由你定义。 |

## 默认成片规格

| 项目 | 规格 |
| --- | --- |
| 时长 | 90 秒 |
| 分辨率 / 帧率 | 1920 × 1080 / 30 fps，共 2700 帧 |
| 容器 / 视频 | MP4 / H.264，yuv420p，CRF 17 |
| 成片音频 | AAC，320 kb/s，48 kHz，立体声 |
| 原始配乐 | WAV，48 kHz，16-bit，立体声 |
| 文字 | 中文主叙事、英文章节眉题，直接合成进画面 |

最终合成使用视频流复制，不对已渲染的画面重复编码；MP4 启用 `faststart`。
